local L = LibStub("AceLocale-3.0"):NewLocale("KuiNameplatesAuras", "esMX", false)
if not L then return end