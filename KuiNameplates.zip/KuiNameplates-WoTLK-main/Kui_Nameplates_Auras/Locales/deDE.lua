local L = LibStub("AceLocale-3.0"):NewLocale("KuiNameplatesAuras", "deDE", false)
if not L then return end