# TSM v2.8.3
Backport of [TradeSkillMaster](https://www.tradeskillmaster.com/) for 3.3.5a

Most porting done by [Various Authors](https://github.com/andrew6180/TradeSkillMaster/network/members)

Large amount of fixes done by [BlueAo - Warmane](https://forum.warmane.com/showthread.php?t=412904) and [Gnomezilla](https://github.com/Bananaman)

This is mostly just making sure the 'go to github' version is the most up to date and patched.

# If you are expericing lua errors and you were previously using another TSM port
Other popular ports use different versions of TSM completely incompatible with this one.

If you are experiecing lua errors **and** you were previously using another version:

Navigate to `<WoW Folder>\WTF\Account\<Account Name>\SavedVariables` and delete any file relating to TSM.

Example:

![https://i.imgur.com/bEpccPg.png](https://i.imgur.com/bEpccPg.png)
