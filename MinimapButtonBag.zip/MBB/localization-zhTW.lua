﻿if( GetLocale() == "zhTW" ) then

MBB_TOOLTIP1 = "Ctrl + 右鍵選擇是否附著在小地圖";
MBB_OPTIONS_HEADER = "選項";
MBB_OPTIONS_OKBUTTON = "確定";
MBB_OPTIONS_CANCELBUTTON = "取消";
MBB_OPTIONS_SLIDEROFF = "無";
MBB_OPTIONS_SLIDERSEK = "秒";
MBB_OPTIONS_SLIDERLABEL = "消失時間:";
MBB_OPTIONS_EXPANSIONLABEL = "展開方向:";
MBB_OPTIONS_EXPANSIONLEFT = "左";
MBB_OPTIONS_EXPANSIONTOP = "上";
MBB_OPTIONS_EXPANSIONRIGHT = "右";
MBB_OPTIONS_EXPANSIONBOTTOM = "下";
MBB_OPTIONS_MAXBUTTONSLABEL = "每列最大圖示:";
MBB_OPTIONS_MAXBUTTONSINFO = "(0=無限制)";
MBB_OPTIONS_ALTEXPANSIONLABEL = "Alt. 展開:";
MBB_HELP1 = "Type \"/mbb <cmd>\" where <cmd> is one of the following:";
MBB_HELP2 = "  |c00ffffffbuttons|r: Shows a list of all frames in the MBB bar";
MBB_HELP3 = "  |c00ffffffreset position|r: 重置 MBB 在小地圖的位置";
MBB_HELP4 = "  |c00ffffffreset all|r: 重置所有選項";
MBB_NOERRORS = "沒有發現錯誤!";

end