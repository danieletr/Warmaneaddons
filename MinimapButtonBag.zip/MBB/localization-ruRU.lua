if( GetLocale() == "ruRU" ) then

MBB_TOOLTIP1 = "Ctrl + Правый клик для смены позиции на миникарте.";
MBB_OPTIONS_HEADER = "Опции";
MBB_OPTIONS_OKBUTTON = "Да";
MBB_OPTIONS_CANCELBUTTON = "Отмена";
MBB_OPTIONS_SLIDEROFF = "Откл";
MBB_OPTIONS_SLIDERSEK = "сек";
MBB_OPTIONS_SLIDERLABEL = "Время сварачивания:";
MBB_OPTIONS_EXPANSIONLABEL = "Расширить:";
MBB_OPTIONS_EXPANSIONLEFT = "Влева";
MBB_OPTIONS_EXPANSIONTOP = "Вверх";
MBB_OPTIONS_EXPANSIONRIGHT = "Вправа";
MBB_OPTIONS_EXPANSIONBOTTOM = "Вниз";
MBB_OPTIONS_MAXBUTTONSLABEL = "Макс. Сумок/длина:";
MBB_OPTIONS_MAXBUTTONSINFO = "(0=бесконечность)";
MBB_OPTIONS_ALTEXPANSIONLABEL = "Alt.Дополнение к:";
MBB_HELP1 = "Введите \"/mbb <cmd>\" где <cmd> одна из команд:";
MBB_HELP2 = "  |c00ffffffbuttons|r: Показать лист всех фреймов для MBB бара";
MBB_HELP3 = "  |c00ffffffreset position|r: сбросить позицию MBB кнопки у мини-карты";
MBB_HELP4 = "  |c00ffffffreset all|r: сбросить все опции";
MBB_NOERRORS = "Ошибок ненайдено!";

end